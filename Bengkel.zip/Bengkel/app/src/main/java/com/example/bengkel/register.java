package com.example.bengkel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class register extends AppCompatActivity {

    //MD5: EA:2F:CB:C1:7A:C9:D5:81:A7:F9:6A:83:77:AB:85:76
    //SHA1: EF:CF:D2:69:F2:A4:25:0F:56:2B:0A:25:DA:7B:D8:7A:20:B7:A4:D2
    //SHA-256: 6E:A0:0F:74:8F:9C:57:7E:A5:41:95:54:76:83:04:16:F8:35:2D:4A:17:A8:3A:F3:5C:7C:56:C3:7D:E6:18:24

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}
